delay = 0.5 
while true do
     os.pullEvent("redstone")
     while redstone.getInput("front") do
        if redstone.getInput("bacK") then
             turtle.attack()
        end
     sleep(delay)
    end
end