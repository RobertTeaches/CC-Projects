local modem = peripheral.find("modem")
local monitor = peripheral.find("monitor")
monitor.setTextScale(4)
monitor.setTextColor(colors.green)
term.redirect(monitor)

local recievingChannel = 2

modem.open(recievingChannel)

while true do
    local event, modemSide, senderChannel, replyChannel, message, senderDistance = os.pullEvent("modem_message")
    if senderChannel == recievingChannel then
        term.clear()
        term.setCursorPos(1,1)
        print(message)
    end
end

