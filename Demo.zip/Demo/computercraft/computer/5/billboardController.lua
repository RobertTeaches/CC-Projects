local modem = peripheral.find("modem")

local sendChannel = 2

while true do
    print("What would you like to display?")
    local output = read()
    modem.transmit(sendChannel, 1, output)
end
