local modem = peripheral.find("modem")
local channel = 123
modem.open(channel)

while true do
    local event, side, channel, replyChannel, message = os.pullEvent("modem_message")
    if message == "w" then
        turtle.forward()
    elseif message == "a" then
        turtle.turnLeft()
    elseif message == "s" then
        turtle.back()
    elseif message == "d" then
        turtle.turnRight()
    elseif message == "space" then
        turtle.up()
    elseif message == "leftShift" then
        turtle.down()
    elseif message == "e" then
        turtle.dig()
    elseif message == "r" then
        turtle.digUp()
    elseif message == "f" then
        turtle.digDown()
    end
end

