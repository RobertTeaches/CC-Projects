local monitor = peripheral.find("monitor")
monitor.setTextScale(2)
term.redirect(monitor)

term.setTextColor(colors.blue)

while true do
 local time = os.time()
 local prettyTime = textutils.formatTime(time, false)
 term.clear()
 print(prettyTime)
 sleep(0.1)
end
 
