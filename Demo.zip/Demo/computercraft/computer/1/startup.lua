local password = "hello"
os.pullEvent = os.pullEventRaw
while true do
    
    print("Enter the password...:")
    local inp = read()
    if inp == password then
        redstone.setOutput("right", true)
        sleep(4)
        redstone.setOutput("right", false)
        term.clear()
    else
        print("Incorrect!!")
        sleep(2)
        term.clear()
    end
end
