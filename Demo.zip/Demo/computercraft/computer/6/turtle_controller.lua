local modem = peripheral.find("modem")
local channel = 123


local function send(data)
    modem.transmit(channel,0,data)
end

while true do
    local eventname, key = os.pullEvent("key")
    key = keys.getName(key)
    send(key)
end