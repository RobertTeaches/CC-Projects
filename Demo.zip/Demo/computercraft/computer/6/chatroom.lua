local modem = peripheral.find("modem")
local channel = 1
local screenname = "Robert"
local password = "2"
modem.open(channel)

term.clear()
size = {term.getSize()}

local function resetCursor()
    term.setCursorPos(1,size[2])
end

resetCursor()

local inputtable = {}
local outputstring = ""

function renderInput()
    term.clearLine()
    resetCursor()
    term.write(">"..string.reverse(table.concat(inputtable)))
end

function clearInput()
    inputtable = {}
    outputstring = ""
end

local function format(message)
    return {"["..screenname.."]: "..message,password}
end

local function selfMessage(message)
    term.setTextColor(colors.green)
    print(format(message)[1])
    term.setTextColor(colors.white)
end

local function send(message)
    modem.transmit(channel, channel, message)
end

local function type()
    local event
    repeat
        event = {os.pullEvent()}
    until (event[1] == "char" or event[1] == "key")
    if(event[1] == "char") then
        table.insert(inputtable,1,event[2])
    elseif(event[1] == "key") then
        event[2] = keys.getName(event[2])
        if(event[2] == "backspace") then
            table.remove(inputtable, 1)
        elseif(event[2] == "enter") then
            term.clearLine()
            resetCursor()
            outputstring = table.concat(inputtable)
            outputstring = string.reverse(outputstring)
            send(outputstring)
            selfMessage(outputstring)
            clearInput()
        end
    end
    renderInput()

end

local function receiveMessage()
    local message = {os.pullEvent("modem_message")}
    local data = message[5]
    if data[2] == password then
        term.clearLine()
        resetCursor()
        printError(data[1])
        renderInput()
    end
end

local function chatloop()
    while true do
        parallel.waitForAny(type,receiveMessage)
    end
end

print("Chatting on channel "..channel.."!")

chatloop()