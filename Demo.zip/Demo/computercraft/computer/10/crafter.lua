
local recipe = {"minecraft:coal",  "", "", nil,
                "minecraft:stick", "", "", nil,
                "",                "", "", nil}

local chest = peripheral.find("inventory")
local modem = peripheral.find("modem")
local turtleName = modem.getNameLocal()


local function grabItemFromChest(item, slot)
    local cList = chest.list()
    for i,chestItem in pairs(cList) do
        if chestItem then
            if chestItem.name == item then
                chest.pushItems(turtleName, i, nil, slot)
                return true
            end
        end
    end
    return false
end

--Will try and fill slots from 'recipe' with as many of the item that it can stack
local function fillCraftingSlots()
    for _,item in pairs(recipe) do
        if item ~= "" then
            if grabItemFromChest(item, _) then
                print("Grabbed "..item.." from chest")
            else
                print("Could not find "..item.." in chest")
                return false
            end
        end
    end
    return true
end

--Clear Inventory
for i=1, 16 do
    turtle.select(i)
    turtle.drop()
end

--Main Loop
while true do
    sleep(.1)
    if fillCraftingSlots() then
        local i = 2
        turtle.select(i)
        turtle.craft()
        while i < 17 and turtle.getItemCount(i) do
            turtle.select(i)
            turtle.drop()
            i = i + 1
        end
        turtle.drop()
    else
        print("Out of materials")
        break
    end
end